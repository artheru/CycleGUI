void initSokol()
{
	
}

void drawSokol(int w, int h)
{
	
}