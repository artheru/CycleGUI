#Install
install vcpkg
vcpkg install freetype glm glew draco